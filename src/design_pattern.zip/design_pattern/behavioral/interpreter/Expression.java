package design_pattern.behavioral.interpreter;

public interface Expression {
   public boolean interpret(String context);
}
