package design_pattern.behavioral.state;

public interface State {
	 void doAction();
}
