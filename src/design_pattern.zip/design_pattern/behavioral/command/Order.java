package design_pattern.behavioral.command;

public interface Order{
	 void execute();
}
