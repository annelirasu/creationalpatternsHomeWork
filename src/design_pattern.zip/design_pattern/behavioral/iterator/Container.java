package design_pattern.behavioral.iterator;

public interface Container {
   public Iterator getIterator();
}
