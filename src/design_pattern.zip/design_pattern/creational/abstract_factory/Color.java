package design_pattern.creational.abstract_factory;

public interface Color {
    void fill();
}
