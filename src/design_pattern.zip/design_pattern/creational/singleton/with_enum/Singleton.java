package design_pattern.creational.singleton.with_enum;

public enum Singleton {
    INSTANCE;
}