package design_pattern.structural.proxy;

public interface OfficeInternetAccess {
    void grantInternetAccess();
}  
