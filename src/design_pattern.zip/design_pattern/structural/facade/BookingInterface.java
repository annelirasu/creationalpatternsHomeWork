package design_pattern.structural.facade;

public interface BookingInterface {
    void book(BookingInfo bookingInfo);
}
