package design_pattern.structural.facade;

public class AddressInfo {
}
