package design_pattern.structural.decorator;

public interface Car {
   void create();
}
