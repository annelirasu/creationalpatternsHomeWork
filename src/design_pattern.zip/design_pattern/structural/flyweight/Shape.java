package design_pattern.structural.flyweight;

public interface Shape {
   void draw();
}
