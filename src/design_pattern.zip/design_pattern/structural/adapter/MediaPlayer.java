package design_pattern.structural.adapter;

public interface MediaPlayer {
   public void play(String audioType, String fileName);
}